package com.hb.puzz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Main Activity for Mosaic Blocks.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        setContent {
            MaterialTheme {
                Surface {
                    MosaicBlocksApp()
                }
            }
        }
    }
}

/**
 * Main app composable - shows home screen and game navigation.
 */
@Composable
fun MosaicBlocksApp() {
    var currentScreen by remember { mutableStateOf("home") }
    
    Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        when (currentScreen) {
            "home" -> HomeScreen(
                onStartNewGame = { currentScreen = "game" },
                onHowToPlay = { currentScreen = "how_to_play" },
                onSettings = { currentScreen = "settings" }
            )
            
            "game" -> GameScreen(
                onPaused = { currentScreen = "pause" },
                onHome = { currentScreen = "home" }
            )
            
            "pause" -> PauseScreen(
                onResume = { currentScreen = "game" },
                onRestart = { currentScreen = "game" }, // In a real app, would reset game
                onHome = { currentScreen = "home" }
            )
            
            "how_to_play" -> HowToPlayScreen(onBack = { currentScreen = "home" })
            
            "settings" -> SettingsScreen(onBack = { currentScreen = "home" })
        }
    }
}

/**
 * Home screen.
 */
@Composable
fun HomeScreen(
    onStartNewGame: () -> Unit,
    onHowToPlay: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Mosaic Blocks",
            style = MaterialTheme.typography.displayLarge.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 48.dp)
        )
        
        Button(
            onClick = onStartNewGame,
            modifier = Modifier
                .fillMaxWidth(0.75f)
                .height(56.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("Start New Game")
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedButton(
            onClick = onHowToPlay,
            modifier = Modifier
                .fillMaxWidth(0.75f)
                .height(56.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("How to Play")
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedButton(
            onClick = onSettings,
            modifier = Modifier
                .fillMaxWidth(0.75f)
                .height(56.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("Settings")
        }
    }
}

/**
 * Game screen.
 */
@Composable
fun GameScreen(
    onPaused: () -> Unit,
    onHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    var score by remember { mutableStateOf(0) }
    
    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Mosaic Blocks") },
                actions = {
                    IconButton(onClick = onPaused) {
                        Icon(Icons.Default.Pause, contentDescription = "Pause")
                    }
                }
            )
        },
        bottomBar = {
            // Piece tray
            LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(8.dp)) {
                items(3) { index ->
                    val pieceColor = when (index % 6) {
                        0 -> Color(0xFFFFB39A)
                        1 -> Color(0xFF7DE3E8)
                        2 -> Color(0xFF9BC5F2)
                        3 -> Color(0xFFFFD166)
                        4 -> Color(0xFFFAD6E8)
                        else -> Color(0xFFCBAACB)
                    }
                    
                    PieceTrayItem(
                        color = pieceColor,
                        onClick = {
                            // Simple placement logic for demo
                            score += 2  // Place 2 blocks
                        }
                    )
                }
            }
        }
    ) { padding ->
        GameBoard(padding)
        
        Text(
            text = "Score: $score",
            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 48.dp + padding.calculateTopPadding())
        )
    }
}

/**
 * Game board with 8x8 grid.
 */
@Composable
fun GameBoard(
    padding: WindowInsets,
    modifier: Modifier = Modifier
) {
    val cellSize = 40.dp
    
    Column(
        modifier = modifier.align(Alignment.Center),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        for (row in 0 until 8) {
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                for (col in 0 until 8) {
                    val isFilled = (row == 3 && col < 4) // Demo pattern
                    BoardCell(isFilled, cellSize)
                }
            }
        }
    }
}

/**
 * Individual board cell.
 */
@Composable
fun BoardCell(
    isFilled: Boolean,
    cellSize: Dp,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(cellSize)
            .clip(RoundedCornerShape(6.dp))
            .background(if (isFilled) MaterialTheme.colorScheme.primary else Color.Transparent)
            .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
    )
}

/**
 * Piece tray item.
 */
@Composable
fun PieceTrayItem(
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .sizeIn(minWidth = 80.dp, minHeight = 40.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.2f))
            .border(2.dp, color, RoundedCornerShape(12.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier.size(30.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(color)
                .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
        )
    }
}

/**
 * Pause screen.
 */
@Composable
fun PauseScreen(
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Paused",
            style = MaterialTheme.typography.displayLarge.copy(fontWeight = FontWeight.Bold)
        )
        
        Spacer(modifier = Modifier.height(48.dp))
        
        Button(
            onClick = onResume,
            modifier = Modifier.fillMaxWidth(0.75f).height(56.dp)
        ) {
            Text("Resume")
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedButton(
            onClick = onRestart,
            modifier = Modifier.fillMaxWidth(0.75m).height(56.dp)
        ) {
            Text("Restart")
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        TextButton(
            onClick = onHome,
            modifier = Modifier.fillMaxWidth(0.75f).height(56.dp)
        ) {
            Text("Home")
        }
    }
}

/**
 * How to Play screen.
 */
@Composable
fun HowToPlayScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Top
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            
            Text(
                text = "How to Play",
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.weight(1f)
            )
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Column(verticalArrangement = Arrangement.spacedBy(24.dp)) {
            Text("Place Pieces", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text("Drag pieces from the tray to empty cells on the board. Pieces must fit entirely within the 8×8 grid without overlapping existing blocks.")
            
            Text("Clear Lines", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text("Fill entire rows or columns to clear them. Multiple lines can be cleared simultaneously for bonus points!")
            
            Text("Scoring System", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text("• 1 point per placed cell")
            Text("• 10 points per completed line")
            Text("• Bonus: 5 × L × (L-1) for clearing L lines at once")
            
            Text("Game Over", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text("When none of your pieces can fit on the board, the game ends. Try to achieve the highest score possible!")
        }
    }
}

/**
 * Settings screen.
 */
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var soundEnabled by remember { mutableStateOf(true) }
    
    Column(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Top
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            
            Text(
                text = "Settings",
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.weight(1f)
            )
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth().height(60.dp)
        ) {
            Text("Sound", style = MaterialTheme.typography.bodyMedium)
            Switch(checked = soundEnabled, onCheckedChange = { soundEnabled = it })
        }
    }
}
