package com.hb.puzz.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hb.puzz.domain.GameEngine
import com.hb.puzz.domain.model.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel for the game screen, managing game state and interactions.
 */
@HiltViewModel
class GameViewModel @Inject constructor(
    private val pieceGenerator: PieceGenerator = PieceGenerator()
) : ViewModel() {

    private val _gameEngine = GameEngine(pieceGenerator.generatePieces(3))
    private val _uiState = MutableStateFlow(GameUiState())
    
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    /**
     * Updates the UI state with current game data.
     */
    private fun updateUIState() {
        val gameState = _gameEngine.state
        _uiState.value = GameUiState(
            board = gameState.board,
            pieces = gameState.pieces,
            score = gameState.score,
            bestScore = gameState.bestScore,
            isGameOver = gameState.isGameOver
        )
    }

    /**
     * Attempts to place the given piece at the specified position.
     */
    fun tryPlacePiece(piece: Piece, x: Int, y: Int) {
        val placed = _gameEngine.tryPlacePiece(piece, x, y)
        updateUIState()
        
        // Check if we should refill pieces
        if (uiState.value.pieces.isEmpty()) {
            viewModelScope.launch {
                // Refill with new pieces
                val newPieces = pieceGenerator.generatePieces(3)
                // We need to handle this in the engine properly
            }
        }
    }

    /**
     * Resets the current game.
     */
    fun resetGame() {
        _gameEngine.resetGame()
        updateUIState()
    }

    /**
     * Saves the current best score if higher than previous.
     */
    fun saveBestScoreIfHigher() {
        val currentState = uiState.value
        val savedBest = currentState.bestScore
        
        if (currentState.score > savedBest) {
            _gameEngine.updateBestScore(currentState.score)
            updateUIState()
        }
    }

    /**
     * Creates a game state from saved data.
     */
    fun loadGameState(savedBoard: GameBoard, savedPieces: List<Piece>) {
        val gameState = GameState(
            board = savedBoard,
            pieces = savedPieces,
            score = 0,
            bestScore = uiState.value.bestScore
        )
        
        _gameEngine.state.copy(pieces = savedPieces).apply {
            // This is a workaround - we need to restructure GameEngine to accept state
        }
    }

    init {
        updateUIState()
    }
}

/**
 * UI state representation for the game screen.
 */
data class GameUiState(
    val board: GameBoard = GameBoard.createEmptyBoard(),
    val pieces: List<Piece> = emptyList(),
    val score: Int = 0,
    val bestScore: Int = 0,
    val isGameOver: Boolean = false
)
