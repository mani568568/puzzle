package com.hb.puzz.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.consumeAllPointerTicks
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.hb.puzz.domain.model.Cell
import kotlinx.coroutines.launch

/**
 * The game board with draggable pieces.
 */
@Composable
fun GameBoard(
    board: com.hb.puzz.domain.model.GameBoard,
    currentPieces: List<com.hb.puzz.domain.model.Piece>,
    onPiecePlaced: (Int, Int) -> Unit, // x, y coordinates for placement
    modifier: Modifier = Modifier,
    cellSize: Dp = 40.dp
) {
    val scope = rememberCoroutineScope()
    
    val boardSize = (board.width * cellSize).dp
    
    Box(
        modifier = modifier
            .size(boardSize)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(
                width = 2.dp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp)
            )
    ) {
        // Draw board grid
        Canvas(modifier = Modifier.matchParentSize()) {
            val cellWidth = size.width / board.width
            val cellHeight = size.height / board.height
            
            for (row in 0 until board.height) {
                for (col in 0 until board.width) {
                    val cellRect = androidx.compose.ui.geometry.Rect(
                        left = col * cellWidth,
                        top = row * cellHeight,
                        right = (col + 1) * cellWidth,
                        bottom = (row + 1) * cellHeight
                    )
                    
                    // Draw grid line
                    drawLine(
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f),
                        start = Offset(cellRect.left, cellRect.top),
                        end = Offset(cellRect.right, cellRect.bottom),
                        strokeWidth = 1.dp.toPx()
                    )
                }
            }
        }
        
        // Draw existing blocks
        board.cells.forEach { (cell, color) ->
            BlockPiece(
                color = Color(android.graphics.Color.parseColor(color.hex)),
                size = cellSize,
                modifier = Modifier.offset(
                    x = (cell.x * cellSize).dp,
                    y = (cell.y * cellSize).dp
                )
            )
        }
        
        // Add pointer input for drag detection (simplified - real implementation would handle dragging pieces from tray)
        Box(modifier = Modifier.matchParentSize()) {
            var lastOffset by remember { mutableStateOf(0 to 0) }
            
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            // Handle drag - this is where we would track piece dragging from tray
                        }
                    }
            )
        }
    }
}

/**
 * Shows a preview of placement (valid in green, invalid in red).
 */
@Composable
fun PlacementPreview(
    modifier: Modifier = Modifier,
    position: IntOffset,
    cells: List<Cell>,
    color: Color,
    isValid: Boolean,
    cellSize: Dp = 40.dp
) {
    if (cells.isEmpty()) return
    
    Box(
        modifier = modifier.offset(
            x = (position.x * cellSize).dp,
            y = (position.y * cellSize).dp
        )
    ) {
        cells.forEach { cell ->
            BlockPiece(
                color = if (isValid) color else MaterialTheme.colorScheme.error,
                size = cellSize,
                modifier = Modifier.offset(
                    x = (cell.x * cellSize).dp,
                    y = (cell.y * cellSize).dp
                )
            )
        }
    }
}
