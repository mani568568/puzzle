package com.hb.puzz

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Main navigation structure for the app.
 */
@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    
    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(
                onContinue = { navController.navigate("game") },
                onStartNewGame = { 
                    // Reset game state
                    navController.navigate("game") 
                },
                onHowToPlay = { navController.navigate("how_to_play") },
                onSettings = { navController.navigate("settings") }
            )
        }
        
        composable("game") {
            GameScreen(
                onPaused = { navController.navigate("pause") },
                onBack = { navController.navigateUp() }
            )
        }
        
        composable("pause") {
            PauseScreen(
                onResume = { navController.popBackStack() },
                onRestart = { 
                    // Restart game
                    navController.popBackStack()
                },
                onHome = { 
                    navController.navigate("home") { 
                        popUpTo("game") { inclusive = true } 
                    }
                }
            )
        }
        
        composable("how_to_play") {
            HowToPlayScreen(
                onBack = { navController.navigateUp() }
            )
        }
        
        composable("settings") {
            SettingsScreen(
                onBack = { navController.navigateUp() }
            )
        }
    }
}

/**
 * Home screen with game options.
 */
@Composable
fun HomeScreen(
    hasSavedGame: Boolean = false,
    onContinue: () -> Unit,
    onStartNewGame: () -> Unit,
    onHowToPlay: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Mosaic Blocks",
            style = MaterialTheme.typography.displayLarge.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 48.dp)
        )
        
        if (hasSavedGame) {
            Button(
                onClick = onContinue,
                modifier = Modifier
                    .fillMaxWidth(0.75f)
                    .height(56.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Continue")
            }
            
            Spacer(modifier = Modifier.height(16.dp))
        }
        
        Button(
            onClick = onStartNewGame,
            modifier = Modifier
                .fillMaxWidth(0.75f)
                .height(56.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("New Game")
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedButton(
            onClick = onHowToPlay,
            modifier = Modifier
                .fillMaxWidth(0.75f)
                .height(56.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("How to Play")
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedButton(
            onClick = onSettings,
            modifier = Modifier
                .fillMaxWidth(0.75f)
                .height(56.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("Settings")
        }
    }
}

/**
 * Game screen.
 */
@Composable
fun GameScreen(
    onPaused: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var score by remember { mutableStateOf(0) }
    
    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Mosaic Blocks") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onPaused) {
                        Icon(Icons.Default.Pause, contentDescription = "Pause")
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
        ) {
            GameBoardUI(score = score)
            
            // Score display
            Column(
                modifier = Modifier.align(Alignment.TopCenter),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text("Score: $score", style = MaterialTheme.typography.titleMedium)
                Text("Best: 100", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

/**
 * Game board UI component.
 */
@Composable
fun GameBoardUI(
    score: Int,
    modifier: Modifier = Modifier
) {
    val cellSize = 40.dp
    
    Column(modifier = modifier.align(Alignment.Center)) {
        // Board grid (8x8)
        for (row in 0 until 8) {
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                for (col in 0 until 8) {
                    Cell(
                        isFilled = (row == 3 && col < 4), // Demo filled cells
                        cellSize = cellSize
                    )
                }
            }
        }
    }
}

/**
 * Individual board cell.
 */
@Composable
fun Cell(
    isFilled: Boolean,
    cellSize: Dp,
    modifier: Modifier = Modifier
) {
    val color = if (isFilled) MaterialTheme.colorScheme.primary else 
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
    
    Box(
        modifier = modifier
            .size(cellSize)
            .background(color)
            .border(1.dp, Color.LightGray, RoundedCornerShape(4.dp))
    )
}

/**
 * Pause screen.
 */
@Composable
fun PauseScreen(
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background.copy(alpha = 0.8f)),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Paused",
            style = MaterialTheme.typography.displayLarge.copy(fontWeight = FontWeight.Bold)
        )
        
        Spacer(modifier = Modifier.height(48.dp))
        
        Button(
            onClick = onResume,
            modifier = Modifier.fillMaxWidth(0.75f).height(56.dp)
        ) {
            Text("Resume")
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedButton(
            onClick = onRestart,
            modifier = Modifier.fillMaxWidth(0.75m).height(56.dp)
        ) {
            Text("Restart")
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        TextButton(
            onClick = onHome,
            modifier = Modifier.fillMaxWidth(0.75f).height(56.dp)
        ) {
            Text("Home")
        }
    }
}

/**
 * How to Play screen.
 */
@Composable
fun HowToPlayScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("How to Play") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text("1. Place Pieces", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text("Drag or tap pieces to place them on the board.")
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text("2. Complete Lines", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text("Fill entire rows or columns to clear them and score points.")
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text("3. Scoring", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text("- 1 point per placed cell")
            Text("- 10 points per completed line")
            Text("- Bonus: 5 × L × (L-1) for clearing L lines at once")
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text("4. Game Over", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text("When no pieces can be placed, the game ends.")
        }
    }
}

/**
 * Settings screen.
 */
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var soundEnabled by remember { mutableStateOf(true) }
    var hapticsEnabled by remember { mutableStateOf(true) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text("Sound", style = MaterialTheme.typography.bodyMedium)
            Switch(
                checked = soundEnabled,
                onCheckedChange = { soundEnabled = it }
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text("Haptics", style = MaterialTheme.typography.bodyMedium)
            Switch(
                checked = hapticsEnabled,
                onCheckedChange = { hapticsEnabled = it }
            )
        }
    }
}
