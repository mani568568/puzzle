package com.hb.puzz.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hb.puzz.domain.model.Piece

/**
 * The main game screen with board and pieces.
 */
@Composable
fun GameScreen(
    state: GameUiState,
    onPiecePlaced: (piece: Piece, x: Int, y: Int) -> Unit,
    onPaused: () -> Unit,
    modifier: Modifier = Modifier,
    cellSize: Dp = 40.dp
) {
    var dragOffset by remember { mutableStateOf(0 to 0) }
    
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top bar with score and pause
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .height(56.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Mosaic Blocks",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.primary
            )
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Score: ${state.score}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(end = 16.dp)
                )
                
                IconButton(onClick = onPaused) {
                    Icon(
                        imageVector = Icons.Default.Pause,
                        contentDescription = "Pause"
                    )
                }
            }
        }
        
        // Score and best score
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        ) {
            Text("Score: ${state.score}", style = MaterialTheme.typography.bodySmall)
            Text("Best: ${state.bestScore}", style = MaterialTheme.typography.bodySmall)
        }
        
        // Board with pieces
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            GameBoard(
                board = state.board,
                currentPieces = state.pieces,
                onPiecePlaced = { x, y -> },
                cellSize = cellSize
            )
            
            // Dragged piece preview
            if (dragOffset.first != 0 || dragOffset.second != 0) {
                PlacementPreview(
                    position = dragOffset,
                    cells = listOf(), // Would be current dragged piece cells
                    color = MaterialTheme.colorScheme.primary,
                    isValid = true,
                    cellSize = cellSize
                )
            }
        }
        
        // Piece tray
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Pieces",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(bottom = 8.dp)
            )
            
            LazyRow(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(state.pieces.size) { index ->
                    val piece = state.pieces[index]
                    
                    PieceTrayItem(
                        piece = piece,
                        onClick = { x, y -> onPiecePlaced(piece, x, y) },
                        cellSize = 30.dp
                    )
                }
            }
        }
    }
}

/**
 * A single item in the piece tray.
 */
@Composable
fun PieceTrayItem(
    piece: Piece,
    onClick: (Int, Int) -> Unit,
    modifier: Modifier = Modifier,
    cellSize: Dp = 30.dp
) {
    val pieceWidth = (piece.bounds.first * cellSize).dp
    val pieceHeight = (piece.bounds.second * cellSize).dp
    
    Box(
        modifier = modifier
            .sizeIn(minWidth = pieceWidth + 16.dp, minHeight = pieceHeight + 16.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(
                width = 2.dp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onClick(0, 0) }, // Would pass calculated position
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier.wrapContentWidth()
                .wrapContentHeight(),
            contentAlignment = Alignment.Center
        ) {
            piece.cells.forEach { cell ->
                BlockPiece(
                    color = Color(android.graphics.Color.parseColor(piece.color.hex)),
                    size = cellSize,
                    modifier = Modifier.offset(
                        x = (cell.x * cellSize).dp,
                        y = (cell.y * cellSize).dp
                    )
                )
            }
        }
    }
}
