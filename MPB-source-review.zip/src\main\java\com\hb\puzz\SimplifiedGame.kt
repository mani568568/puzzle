package com.hb.puzz

import android.graphics.Color
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Simplified game state for demonstration.
 */
data class GameState(
    val board: List<List<String?>> = List(8) { List(8) { null } },
    var score: Int = 0,
    val pieces: List<PieceData> = listOf()
)

data class PieceData(
    val cells: List<Pair<Int, Int>>,
    val colorHex: String
)

/**
 * Main game activity content.
 */
@Composable
fun GameActivityContent() {
    // Initialize game state with some sample blocks and 3 random pieces
    var gameState by remember { mutableStateOf(initialGameState()) }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .height(56.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Mosaic Blocks",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.primary
            )
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Score: ${gameState.score}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(end = 16.dp)
                )
                
                IconButton(onClick = { /* TODO */ }) {
                    Icon(
                        imageVector = Icons.Default.Pause,
                        contentDescription = "Pause"
                    )
                }
            }
        }
        
        // Score and best score
        Row(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
            Text("Score: ${gameState.score}", style = MaterialTheme.typography.bodySmall)
            Spacer(modifier = Modifier.weight(1f))
            Text("Best: 0", style = MaterialTheme.typography.bodySmall) // Would use saved value
        }
        
        // Game board - 8x8 grid
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            val cellSize = 40.dp
            
            for (row in 0 until 8) {
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    for (col in 0 until 8) {
                        BoardCell(
                            value = gameState.board[row][col],
                            onClick = { x, y ->
                                // Simplified placement logic
                                val placedCells = listOf(Pair(x, y))
                                placePiece(gameState, gameState.pieces[0], x to y)
                                    .let { newGameState ->
                                        gameState = newGameState
                                    }
                            }
                        )
                    }
                }
            }
        }
        
        // Piece tray
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Pieces",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(bottom = 8.dp)
            )
            
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                gameState.pieces.forEach { piece ->
                    PiecePreview(
                        cells = piece.cells,
                        colorHex = piece.colorHex
                    )
                }
            }
        }
    }
}

/**
 * Initial game state with sample blocks.
 */
fun initialGameState(): GameState {
    // Start with some random pieces
    val pieces = listOf(
        PieceData(listOf(0 to 0, 1 to 0), "#FFB39A"),
        PieceData(listOf(0 to 0, 0 to 1, 0 to 2), "#7DE3E8"),
        PieceData(listOf(0 to 0, 1 to 0, 2 to 0, 1 to 1), "#FFD166")
    )
    
    return GameState(
        board = List(8) { List(8) { null } },
        score = 0,
        pieces = pieces
    )
}

/**
 * Board cell composable.
 */
@Composable
fun BoardCell(
    value: String?,
    onClick: (Int, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(40.dp)
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(6.dp))
            .background(
                if (value != null) ComposeColor(Color.parseColor(value)) else 
                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
            )
            .border(1.dp, ComposeColor(0xFFDCE4EF), androidx.compose.foundation.shape.RoundedCornerShape(6.dp))
            .clickable { onClick(0, 0) }, // Would pass actual position
        contentAlignment = Alignment.Center
    ) {
        if (value != null) {
            Box(
                modifier = Modifier.size(32.dp)
                    .clip(androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
                    .background(ComposeColor(Color.parseColor(value)))
                    .border(2.dp, ComposeColor(Color.parseColor(value)).copy(alpha = 0.3f), androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
            )
        }
    }
}

/**
 * Piece preview in the tray.
 */
@Composable
fun PiecePreview(
    cells: List<Pair<Int, Int>>,
    colorHex: String,
    modifier: Modifier = Modifier
) {
    val cellSize = 20.dp
    
    Box(
        modifier = modifier
            .padding(8.dp)
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
            .background(ComposeColor(Color.parseColor(colorHex)).copy(alpha = 0.1f)),
        contentAlignment = Alignment.Center
    ) {
        cells.forEach { (x, y) ->
            Box(
                modifier = Modifier.offset(x * cellSize, y * cellSize)
                    .size(cellSize)
                    .clip(androidx.compose.foundation.shape.RoundedCornerShape(4.dp))
                    .background(ComposeColor(Color.parseColor(colorHex)))
                    .border(1.dp, ComposeColor(Color.parseColor(colorHex)).copy(alpha = 0.5f), androidx.compose.foundation.shape.RoundedCornerShape(4.dp))
            )
        }
    }
}

/**
 * Simple placement logic - adds a block to the board.
 */
fun placePiece(
    currentState: GameState,
    piece: PieceData,
    position: Pair<Int, Int>
): GameState {
    val (x, y) = position
    val newBoard = currentState.board.toMutableList().apply {
        for ((dx, dy) in piece.cells) {
            if (x + dx < 8 && y + dy < 8) {
                this[y + dy][x + dx] = piece.colorHex
            }
        }
    }
    
    // For demonstration, just add one point per placed cell
    val newScore = currentState.score + piece.cells.size
    
    return GameState(
        board = newBoard,
        score = newScore,
        pieces = currentState.pieces
    )
}
