package com.hb.puzz

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.hb.puzz.data.GameDatastore
import com.hb.puzz.domain.model.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Unit tests for GameDatastore serialization functions.
 */
@RunWith(AndroidJUnit4::class)
class GameDatastoreTest {
    
    @Test
    fun `serialize_and_parse_board`() = runBlocking {
        val board = GameBoard.createEmptyBoard()
        
        // Add some cells to the board
        val cells = mapOf(
            Cell(0, 0) to PieceColor.CORAL,
            Cell(3, 4) to PieceColor.TEAL,
            Cell(7, 7) to PieceColor.BLUE
        )
        
        val testBoard = board.copy(cells = cells)
        
        // Serialize
        val serialized = GameDatastore.serializeBoard(testBoard)
        
        // Parse back
        val parsedBoard = GameDatastore.parseBoard(serialized)
        
        // Verify cells match
        assertEquals(testBoard.cells.size, parsedBoard.cells.size)
        
        testBoard.cells.forEach { (cell, color) ->
            assertEquals(color, parsedBoard.cells[cell])
        }
    }
    
    @Test
    fun `serialize_and_parse_piece`() = runBlocking {
        val piece = Piece(
            id = 42,
            cells = listOf(Cell(0, 0), Cell(1, 0), Cell(2, 0)),
            color = PieceColor.CORAL
        )
        
        // Serialize
        val serialized = GameDatastore.serializePieces(listOf(piece))
        
        // Parse back
        val parsedPieces = GameDatastore.parsePieces(serialized)
        
        assertEquals(1, parsedPieces.size)
        assertEquals(piece.id, parsedPieces[0].id)
        assertEquals(piece.cells.size, parsedPieces[0].cells.size)
        assertEquals(piece.color, parsedPieces[0].color)
    }
    
    @Test
    fun `serialize_and_parse_multiple_pieces`() = runBlocking {
        val pieces = listOf(
            Piece(1, listOf(Cell(0, 0)), PieceColor.CORAL),
            Piece(2, listOf(Cell(0, 0), Cell(0, 1)), PieceColor.TEAL),
            Piece(3, listOf(Cell(0, 0), Cell(1, 0), Cell(2, 0)), PieceColor.BLUE)
        )
        
        // Serialize
        val serialized = GameDatastore.serializePieces(pieces)
        
        // Parse back
        val parsedPieces = GameDatastore.parsePieces(serialized)
        
        assertEquals(pieces.size, parsedPieces.size)
    }
    
    @Test
    fun `serialize_empty_board`() = runBlocking {
        val board = GameBoard.createEmptyBoard()
        
        val serialized = GameDatastore.serializeBoard(board)
        
        // Empty map should serialize to empty string or handle gracefully
        assertNotNull(serialized)
    }
    
    @Test
    fun `parse_invalid_serialization_returns_graceful_result`() = runBlocking {
        // Test parsing malformed data
        val result = GameDatastore.parsePieces("invalid;data")
        
        // Should return empty list for invalid input
        assertEquals(0, result.size)
    }
}
