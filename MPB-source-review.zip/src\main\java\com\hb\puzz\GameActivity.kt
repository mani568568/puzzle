package com.hb.puzz

import android.graphics.Color
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Full game activity with all functionality.
 */
class GameActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        setContent {
            MaterialTheme {
                MosaicBlocksGame()
            }
        }
    }
}

@Composable
fun MosaicBlocksGame() {
    var score by remember { mutableStateOf(0) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mosaic Blocks") },
                actions = {
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Pause, contentDescription = "Pause")
                    }
                }
            )
        },
        bottomBar = {
            PieceTray(score)
        }
    ) { padding ->
        GameBoard(padding)
        
        Text(
            text = "Score: $score",
            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 48.dp + padding.calculateTopPadding())
        )
    }
}

/**
 * The game board (8x8 grid).
 */
@Composable
fun GameBoard(
    padding: WindowInsets,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.align(Alignment.Center), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        for (row in 0 until 8) {
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                for (col in 0 until 8) {
                    val isFilled = (row == 3 && col < 4)
                    BoardCell(isFilled, onClick = {})
                }
            }
        }
    }
}

/**
 * Individual board cell.
 */
@Composable
fun BoardCell(
    isFilled: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .size(40.dp)
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(6.dp))
            .background(if (isFilled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
            .border(1.dp, Color.LightGray.copy(alpha = 0.5f), androidx.compose.foundation.shape.RoundedCornerShape(6.dp))
            .clickable { onClick() }
    )
}

/**
 * Piece tray with 3 pieces.
 */
@Composable
fun PieceTray(
    score: Int,
    modifier: Modifier = Modifier
) {
    LazyRow(modifier = modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        items(3) { index ->
            val pieceColors = listOf(
                Color(0xFFFFB39A),
                Color(0xFF7DE3E8),
                Color(0xFF9BC5F2)
            )
            
            PieceTrayItem(pieceColors[index], onClick = {})
        }
    }
}

/**
 * A single piece in the tray.
 */
@Composable
fun PieceTrayItem(
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .sizeIn(minWidth = 80.dp, minHeight = 40.dp)
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.2f))
            .border(2.dp, color, androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier.size(30.dp)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
                .background(color)
                .border(1.dp, Color.WHITE.copy(alpha = 0.5f), androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
        )
    }
}
