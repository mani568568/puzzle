package com.hb.puzz.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.createDataStore
import com.hb.puzz.domain.model.Cell
import com.hb.puzz.domain.model.GameBoard
import com.hb.puzz.domain.model.Piece
import com.hb.puzz.domain.model.PieceColor
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Manages game data persistence using DataStore.
 */
class GameDatastore(context: Context) {
    
    private val dataStore: DataStore<Preferences> = context.createDataStore(name = "game_settings")

    companion object {
        // Settings keys
        private val KEY_SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
        private val KEY_HAPTICS_ENABLED = booleanPreferencesKey("haptics_enabled")
        private val KEY_DARK_THEME = booleanPreferencesKey("dark_theme")
        
        // Game state keys
        private val KEY_SCORE = intPreferencesKey("current_score")
        private val KEY_BEST_SCORE = intPreferencesKey("best_score")
        private val KEY_BOARD_STATE = stringPreferencesKey("board_state")
        private val KEY_PIECES_STATE = stringPreferencesKey("pieces_state")
        
        // Serialize board cells as "x,y;color" pairs separated by "|"
        fun serializeBoard(board: GameBoard): String {
            return board.cells.map { (cell, color) ->
                "${cell.x},${cell.y};${color.hex}"
            }.joinToString(separator = "|")
        }

        // Parse serialized board back
        fun parseBoard(serialized: String): GameBoard {
            val cells = mutableMapOf<Cell, PieceColor>()
            
            serialized.split("|").filter { it.isNotEmpty() }.forEach { pair ->
                val (pos, colorHex) = pair.split(";")
                val (x, y) = pos.split(",").map { it.toIntOrNull() ?: 0 }
                val color = PieceColor.values().firstOrNull { it.hex == colorHex } ?: PieceColor.CORAL
                
                cells[Cell(x, y)] = color
            }
            
            return GameBoard(cells = cells)
        }

        // Serialize pieces for storage
        fun serializePieces(pieces: List<Piece>): String {
            return pieces.joinToString(separator = ";") { piece ->
                val cellData = piece.cells.map { "${it.x},${it.y}" }.joinToString(",")
                "${piece.id};${cellData};${piece.color.hex}"
            }
        }

        // Parse serialized pieces back
        fun parsePieces(serialized: String): List<Piece> {
            return serialized.split(";").filter { it.isNotEmpty() }.mapNotNull { pieceStr ->
                val parts = pieceStr.split(";")
                if (parts.size < 3) return@mapNotNull null
                
                val id = parts[0].toIntOrNull() ?: return@mapNotNull null
                val colorHex = parts.last()
                val color = PieceColor.values().firstOrNull { it.hex == colorHex } ?: return@mapNotNull null
                val cells = parts[1].split(",").chunked(2).mapNotNull { coords ->
                    if (coords.size != 2) return@mapNotNull null
                    Cell(
                        x = coords[0].toIntOrNull() ?: return@mapNotNull null,
                        y = coords[1].toIntOrNull() ?: return@mapNotNull null
                    )
                }
                
                Piece(id, cells, color)
            }
        }
    }

    // Settings flows
    val soundEnabledFlow: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[KEY_SOUND_ENABLED] ?: true
    }

    val hapticsEnabledFlow: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[KEY_HAPTICS_ENABLED] ?: true
    }

    val darkThemeFlow: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[KEY_DARK_THEME] ?: false
    }

    // Game state flows
    val currentScoreFlow: Flow<Int> = dataStore.data.map { prefs ->
        prefs[KEY_SCORE] ?: 0
    }

    val bestScoreFlow: Flow<Int> = dataStore.data.map { prefs ->
        prefs[KEY_BEST_SCORE] ?: 0
    }

    val savedGameBoardFlow: Flow<GameBoard?> = dataStore.data.map { prefs ->
        prefs[KEY_BOARD_STATE]?.let { serialize ->
            if (serialize.isEmpty()) null else parseBoard(serialize)
        }
    }

    val savedPiecesFlow: Flow<List<Piece>?> = dataStore.data.map { prefs ->
        prefs[KEY_PIECES_STATE]?.let { serialize ->
            if (serialize.isEmpty()) null else parsePieces(serialize)
        }
    }

    // Update methods
    suspend fun updateSoundEnabled(enabled: Boolean) {
        dataStore.edit { prefs ->
            prefs[KEY_SOUND_ENABLED] = enabled
        }
    }

    suspend fun updateHapticsEnabled(enabled: Boolean) {
        dataStore.edit { prefs ->
            prefs[KEY_HAPTICS_ENABLED] = enabled
        }
    }

    suspend fun updateDarkTheme(enabled: Boolean) {
        dataStore.edit { prefs ->
            prefs[KEY_DARK_THEME] = enabled
        }
    }

    suspend fun updateScore(score: Int) {
        dataStore.edit { prefs ->
            prefs[KEY_SCORE] = score
        }
    }

    suspend fun updateBestScore(bestScore: Int) {
        dataStore.edit { prefs ->
            prefs[KEY_BEST_SCORE] = bestScore
        }
    }

    suspend fun saveGameState(board: GameBoard, pieces: List<Piece>) {
        dataStore.edit { prefs ->
            prefs[KEY_BOARD_STATE] = serializeBoard(board)
            prefs[KEY_PIECES_STATE] = serializePieces(pieces)
        }
    }

    suspend fun clearSavedGame() {
        dataStore.edit { prefs ->
            prefs[KEY_BOARD_STATE] = ""
            prefs[KEY_PIECES_STATE] = ""
            prefs[KEY_SCORE] = 0
        }
    }
}
